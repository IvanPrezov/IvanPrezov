# task_kalkulator_s
The application is to calculate monthly net earnings in PLN on a contract in Germany, Great Britain and Poland.

#### Project dependencies

1. Java 7
2. Spring Boot 2.0.3
3. Apache Tomcat 8.5.31
4. Gradle 4.2.1
5. JSP + JSTL
6. Database: IBM Cloudant

P.S I haven't done any fields validation, though I know that it should be done. Sorry.
